$(document).ready(function() {
    $("#offers-button").click(function() {
        $("#offers-content").slideToggle("slow");
    });
});
